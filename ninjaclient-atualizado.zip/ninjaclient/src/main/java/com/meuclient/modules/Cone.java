package com.meuclient.modules;

/** Teste de "esta a frente": o angulo entre a direcao (dx,dy,dz) e o alvo (tx,ty,tz) cabe no cone? Sem Minecraft. */
final class Cone {
    private Cone() {}

    /** minCos = cosseno do meio-angulo do cone (0,5 = 60 graus). Sem direcao ou em cima do alvo: true. */
    static boolean contains(double dx, double dy, double dz, double tx, double ty, double tz, double minCos) {
        double dl = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double tl = Math.sqrt(tx * tx + ty * ty + tz * tz);
        if (dl < 1e-9 || tl < 1e-9) return true;
        return (dx * tx + dy * ty + dz * tz) / (dl * tl) >= minCos;
    }
}
