package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.MeuClient;
import com.meuclient.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/**
 * NoFall: sem dano de queda. Em vez de mandar um pacote extra, o ClientPlayNetworkHandlerMixin troca
 * o "estou no chao" dos pacotes de movimento que o cliente ja envia por `true` enquanto voce cai.
 * Assim o servidor nao soma a queda do tick e zera o fallDistance dele (um pacote extra depois do
 * movimento ja deixaria o servidor somar a queda, e a ~3,9 blocos/tick isso ja da dano).
 *
 * So comeca depois de TRIGGER_FALL blocos de queda (o dano so aparece acima de 3), para nao mandar
 * "no chao" no ar sem necessidade. Fica de fora quando: criativo/espectador, elytra, agua/lava,
 * escada/trepadeira, subindo, e quando o smash da clava precisa da queda no servidor (veja abaixo).
 *
 * Smash: o dano do smash usa o fallDistance do SERVIDOR; o NoFall zera ele. Por isso, com clava na
 * mao (ou AutoMace ligado) e um jogador a SMASH_RANGE blocos, o NoFall nao age. Nesse caso uma
 * queda longa que nao acerte ninguem pode dar dano.
 */
public class NoFall extends Module {
    private static final double TRIGGER_FALL = 2.0;  // dano de queda so a partir de 3 blocos
    private static final double SMASH_RANGE = 12.0;  // mesmo alcance de equip do AutoMace

    public NoFall() {
        super("NoFall", Category.WORLD);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    /** Chamado pelo mixin a cada pacote de movimento que ainda diz "no ar". */
    public boolean shouldSpoof() {
        if (!isEnabled() || mc.player == null) return false;
        PlayerEntity p = mc.player;
        if (p.isCreative() || p.isSpectator()) return false;
        if (p.isFallFlying() || p.isTouchingWater() || p.isInLava() || p.isClimbing()) return false;
        if (p.getVelocity().y >= 0 || p.fallDistance <= TRIGGER_FALL) return false;
        return !smashNeedsFall();
    }

    private boolean smashNeedsFall() {
        boolean maceReady = mc.player.getMainHandStack().isOf(Items.MACE);
        if (!maceReady) {
            Module mace = MeuClient.modules == null ? null : MeuClient.modules.get("AutoMace");
            maceReady = mace != null && mace.isEnabled();
        }
        return maceReady && Combat.nearestPlayer(mc, SMASH_RANGE) != null;
    }

    /** Copia do pacote de movimento com onGround = true (mesmo tipo, mesmos campos). */
    public static PlayerMoveC2SPacket withGround(PlayerMoveC2SPacket p) {
        boolean pos = p.changesPosition(), look = p.changesLook(), hc = p.horizontalCollision();
        if (pos && look) {
            return new PlayerMoveC2SPacket.Full(p.getX(0.0), p.getY(0.0), p.getZ(0.0),
                    p.getYaw(0f), p.getPitch(0f), true, hc);
        }
        if (pos) return new PlayerMoveC2SPacket.PositionAndOnGround(p.getX(0.0), p.getY(0.0), p.getZ(0.0), true, hc);
        if (look) return new PlayerMoveC2SPacket.LookAndOnGround(p.getYaw(0f), p.getPitch(0f), true, hc);
        return new PlayerMoveC2SPacket.OnGroundOnly(true, hc);
    }
}
