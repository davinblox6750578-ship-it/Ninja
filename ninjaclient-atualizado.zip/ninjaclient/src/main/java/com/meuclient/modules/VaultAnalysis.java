package com.meuclient.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Resume uma gravacao da sequencia de itens de UMA caixa: intervalo entre trocas, itens mais
 * frequentes e se ha ciclo (ou repeticao parcial). Sem Minecraft: so tempos (nanos) e ids de item.
 */
final class VaultAnalysis {
    private VaultAnalysis() {}

    static String report(List<Long> timesNanos, List<String> items) {
        int n = items.size();
        if (n < 8) return "poucas trocas (" + n + ") para analisar: fique mais tempo perto da caixa ativa";

        VaultForecast<String> f = new VaultForecast<>(5000);
        for (int i = 0; i < n; i++) f.observe(timesNanos.get(i), items.get(i));

        List<Long> d = new ArrayList<>();
        for (int i = 1; i < n; i++) d.add((timesNanos.get(i) - timesNanos.get(i - 1)) / 1_000_000L);
        List<Long> sorted = new ArrayList<>(d);
        Collections.sort(sorted);
        double secs = (timesNanos.get(n - 1) - timesNanos.get(0)) / 1e9;

        StringBuilder sb = new StringBuilder();
        sb.append(n).append(" trocas em ").append(String.format(Locale.ROOT, "%.0f", secs))
          .append(" s; intervalo mediano ").append(sorted.get(sorted.size() / 2))
          .append(" ms (min ").append(sorted.get(0)).append(", max ").append(sorted.get(sorted.size() - 1)).append(")");

        Map<String, Integer> counts = new HashMap<>();
        for (String it : items) counts.merge(it, 1, Integer::sum);
        List<Map.Entry<String, Integer>> byCount = new ArrayList<>(counts.entrySet());
        byCount.sort((a, b) -> b.getValue() - a.getValue());
        sb.append("\nitens: ");
        for (int i = 0; i < Math.min(5, byCount.size()); i++) {
            if (i > 0) sb.append(", ");
            sb.append(shortName(byCount.get(i).getKey())).append(" x").append(byCount.get(i).getValue());
        }
        if (byCount.size() > 5) sb.append(" (+").append(byCount.size() - 5).append(" outros)");

        int p = f.period();
        if (p > 0) {
            List<String> cycle = f.cycle();
            List<String> names = new ArrayList<>();
            for (String c : cycle) names.add(shortName(c));
            sb.append("\nCICLO de ").append(p).append(" itens (intervalo ").append(f.baseNanos() / 1_000_000L)
              .append(" ms): ").append(String.join(" > ", names));
            return sb.toString();
        }

        if (!f.regular()) sb.append("\nintervalo irregular entre as trocas");

        List<String> s = f.slots();
        int m = s.size();
        Map<String, Integer> sc = new HashMap<>();
        for (String it : s) sc.merge(it, 1, Integer::sum);
        double chance = 0;
        for (int c : sc.values()) { double q = (double) c / m; chance += q * q; }

        int maxLag = Math.min(VaultForecast.MAX_PERIOD, m / 2);
        double[] fracs = new double[maxLag + 1];
        double best = 0;
        for (int q = 1; q <= maxLag; q++) {
            int match = 0;
            for (int i = q; i < m; i++) if (s.get(i).equals(s.get(i - q))) match++;
            fracs[q] = (double) match / (m - q);
            best = Math.max(best, fracs[q]);
        }
        int bestP = 0; // menor lag quase tao bom quanto o melhor (multiplos do periodo real empatam)
        for (int q = 1; q <= maxLag; q++) if (fracs[q] >= best - 0.03) { bestP = q; break; }
        best = bestP == 0 ? 0 : fracs[bestP];
        String detail = "a cada " + bestP + " trocas coincide " + pct(best) + " (acaso ~" + pct(chance) + ")";
        if (best >= 0.6 && best > chance + 0.25) {
            sb.append("\npossivel padrao parcial: ").append(detail);
        } else {
            sb.append("\nsem padrao visivel (").append(detail).append("): o sorteio parece aleatorio");
        }
        return sb.toString();
    }

    private static String pct(double v) { return String.format(Locale.ROOT, "%.0f%%", v * 100); }

    private static String shortName(String id) { return id.startsWith("minecraft:") ? id.substring(10) : id; }
}
