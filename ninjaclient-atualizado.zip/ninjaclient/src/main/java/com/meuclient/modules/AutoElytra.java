package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.Vec3d;

/**
 * AutoElytra: combo elytra + clava (smash).
 *
 * A clava so da o smash se voce NAO estiver planando (vanilla: queda > 1,5 e sem elytra aberta).
 * A tecnica dos jogadores e: mergulhar com a elytra no inimigo, trocar a elytra pelo peitoral
 * quando estiver perto o bastante e bater com a clava. O modulo faz isso sozinho:
 *
 *  1. Detecta que voce esta VOANDO de elytra (elytra no peito + pose de planar).
 *  2. Quando um jogador A FRENTE da sua direcao chega a MACE_RANGE blocos, poe a clava na mao
 *     (UMA vez por voo: se voce trocar de slot, por exemplo para o foguete, o modulo nao briga).
 *  3. Quando ele chega a SWAP_RANGE blocos (ainda a frente), troca a elytra pelo melhor peitoral do inventario
 *     (3 cliques de inventario no mesmo tick, sem abrir a tela) - isso para o voo.
 *  4. Caindo (fallDistance > 1,5) e com a CAIXA do alvo no alcance, mira e ataca UMA vez.
 *  5. Depois do golpe, ao pousar, se o golpe nao sair em GIVE_UP_TICKS ou se ninguem mais estiver
 *     perto, poe a elytra de volta no peito (nunca fica sem elytra no ar).
 * So troca se tiver clava na hotbar E um peitoral no inventario (senao nao tira sua elytra a toa).
 */
public class AutoElytra extends Module {
    private static final double MACE_RANGE = 12.0;  // pega a clava
    private static final double SWAP_RANGE = 7.0;   // troca elytra -> peitoral
    private static final double REACH = 3.0;        // olhos -> caixa do alvo
    private static final double MIN_FALL = 1.5;     // queda minima do smash
    private static final int GIVE_UP_TICKS = 25;    // trocou e nao bateu: devolve a elytra apos isso (1,25 s)
    private static final double AHEAD_COS = 0.5;    // "a frente" = ate 60 graus da sua direcao de voo
    private static final double MIN_SPEED_SQ = 0.09; // abaixo de 0,3 bloco/tick usa para onde voce olha
    private static final int REEQUIP_TICKS = 12;    // depois do golpe, volta a elytra apos isso (ou ao pousar)
    private static final int CHEST_SCREEN_SLOT = 6; // slot do peitoral na tela do jogador

    private boolean swapped;     // ja trocou elytra -> peitoral neste mergulho
    private boolean attacked;    // ja bateu neste mergulho
    private int reequipTimer;
    private int swapAge;         // ticks desde a troca sem ter batido
    private boolean maceTried;   // ja tentou pegar a clava neste voo

    public AutoElytra() {
        super("AutoElytra", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onDisable() {
        swapped = false;
        attacked = false;
        maceTried = false;
        swapAge = 0;
        reequipTimer = 0;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || !mc.player.isAlive()) return;
        if (mc.player.currentScreenHandler != mc.player.playerScreenHandler) return;

        // depois do combo: devolve a elytra. Se o golpe nao sair (alvo desviou ou saiu do alcance),
        // devolve tambem apos GIVE_UP_TICKS ou quando nao ha mais ninguem perto: senao voce cairia sem elytra
        if (swapped) {
            if (attacked && --reequipTimer > 0 && !mc.player.isOnGround()) return;
            boolean giveUp = !attacked && (++swapAge > GIVE_UP_TICKS || Combat.nearestPlayer(mc, MACE_RANGE) == null);
            if (attacked || mc.player.isOnGround() || giveUp) {
                putBack();
                swapped = false;
                attacked = false;
                return;
            }
        }

        boolean gliding = isGliding();

        if (!swapped) {
            if (!gliding) {
                maceTried = false; // o voo acabou: o proximo voo pode pegar a clava de novo
                return;
            }
            // so conta quem esta a FRENTE da sua direcao: nao troca por quem so passa por baixo ou atras
            if (nearestAhead(MACE_RANGE) == null) return;

            int maceSlot = findHotbar(Items.MACE);
            if (maceSlot == -1) return;
            if (!maceTried) { // uma vez por voo, para nao brigar com o slot que voce escolher
                maceTried = true;
                if (mc.player.getInventory().getSelectedSlot() != maceSlot) {
                    mc.player.getInventory().setSelectedSlot(maceSlot);
                }
            }

            // perto o bastante: troca elytra -> peitoral (para o voo e deixa o smash valer)
            if (nearestAhead(SWAP_RANGE) == null) return;
            int chest = findBestChestplate();
            if (chest == -1) return;
            swapChest(chest);
            swapped = true;
            attacked = false;
            swapAge = 0;
            reequipTimer = REEQUIP_TICKS;
            return;
        }

        // ja trocou: ataca uma vez quando a queda for suficiente e o alvo estiver ao alcance
        if (attacked) return;
        if (isGliding() || mc.player.fallDistance <= MIN_FALL) return;
        if (!mc.player.getMainHandStack().isOf(Items.MACE)) {
            int maceSlot = findHotbar(Items.MACE);
            if (maceSlot == -1) return;
            mc.player.getInventory().setSelectedSlot(maceSlot);
            return;
        }
        PlayerEntity target = Combat.nearestPlayerInReach(mc, REACH);
        if (target == null || target.isBlocking()) return;

        Combat.aimAt(mc, target, 180f);
        Combat.attack(mc, target);
        attacked = true;
        reequipTimer = REEQUIP_TICKS;
    }

    // ---------------------------------------------------------------- elytra

    /** Voando de elytra: elytra no peito, no ar e na pose de planar (nome da pose muda entre mapeamentos). */
    private boolean isGliding() {
        if (!mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) return false;
        if (mc.player.isOnGround()) return false;
        String pose = mc.player.getPose().name();
        return pose.equals("GLIDING") || pose.equals("FALL_FLYING");
    }

    /** Jogador mais proximo (a ate `range` blocos da caixa dele) que esta a FRENTE da sua direcao de voo. */
    private PlayerEntity nearestAhead(double range) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d dir = mc.player.getVelocity();
        if (dir.lengthSquared() < MIN_SPEED_SQ) dir = mc.player.getRotationVec(1.0f); // quase parado: para onde olha
        PlayerEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator() || p.isInvulnerable()) continue;
            double d = Combat.distanceToBox(eye, p.getBoundingBox());
            if (d > range || d >= bestDist) continue;
            Vec3d to = p.getBoundingBox().getCenter().subtract(eye);
            if (!Cone.contains(dir.x, dir.y, dir.z, to.x, to.y, to.z, AHEAD_COS)) continue;
            best = p;
            bestDist = d;
        }
        return best;
    }

    /** Troca o item do peito com o do slot do inventario (3 cliques PICKUP: pega, poe no peito, devolve). */
    private void swapChest(int inventoryIndex) {
        int screenSlot = toScreenSlot(inventoryIndex);
        int sync = mc.player.playerScreenHandler.syncId;
        mc.interactionManager.clickSlot(sync, screenSlot, 0, SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(sync, CHEST_SCREEN_SLOT, 0, SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(sync, screenSlot, 0, SlotActionType.PICKUP, mc.player);
    }

    /** Poe a elytra de volta no peito, se o peito nao for ela e houver uma elytra no inventario. */
    private void putBack() {
        if (mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) return;
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.ELYTRA)) {
                swapChest(i);
                return;
            }
        }
    }

    /** indice do inventario (0-8 hotbar, 9-35 mochila) -> slot da tela do jogador. */
    private static int toScreenSlot(int i) {
        return i < 9 ? 36 + i : i;
    }

    // --------------------------------------------------------------- buscas

    private int findHotbar(net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    /** Melhor peitoral do inventario (netherite > diamante > ferro > cobre > malha > ouro > couro). */
    private int findBestChestplate() {
        int best = -1, bestRank = -1;
        for (int i = 0; i < 36; i++) {
            int rank = rank(mc.player.getInventory().getStack(i));
            if (rank > bestRank) { bestRank = rank; best = i; }
        }
        return best;
    }

    private static int rank(ItemStack stack) {
        if (stack.isEmpty()) return -1;
        String path = Registries.ITEM.getId(stack.getItem()).getPath();
        if (!path.endsWith("_chestplate")) return -1;
        if (path.startsWith("netherite")) return 7;
        if (path.startsWith("diamond")) return 6;
        if (path.startsWith("iron")) return 5;
        if (path.startsWith("copper")) return 4;
        if (path.startsWith("chainmail")) return 3;
        if (path.startsWith("golden")) return 2;
        return 1;
    }
}
