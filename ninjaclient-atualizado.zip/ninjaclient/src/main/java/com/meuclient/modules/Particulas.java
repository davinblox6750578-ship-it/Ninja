package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.MeuClient;
import com.meuclient.Module;
import net.minecraft.particle.ParticleType;
import net.minecraft.particle.ParticleTypes;

import java.util.Set;

/**
 * Particulas (menos lag): vem LIGADO por padrao. Corta as particulas pesadas
 * ou desnecessarias e a animacao do totem na tela:
 *  - explosoes (cristal do End, ancora de respawn);
 *  - mace: rajada de vento (gust) e pilar de poeira do smash;
 *  - totem: particulas do totem (e a animacao do item na tela);
 *  - ancora: particulas do portal reverso;
 *  - outras: fumaca, nuvem, poof, flash, golpe em arco e indicador de dano.
 * Mantem as particulas de critico, que ajudam a ver o acerto.
 * Clique no nome no menu para desligar e voltar as particulas normais.
 */
public class Particulas extends Module {
    private static final Set<ParticleType<?>> BLOCKED = Set.<ParticleType<?>>of(
            ParticleTypes.EXPLOSION,
            ParticleTypes.EXPLOSION_EMITTER,
            ParticleTypes.GUST,
            ParticleTypes.SMALL_GUST,
            ParticleTypes.GUST_EMITTER_LARGE,
            ParticleTypes.GUST_EMITTER_SMALL,
            ParticleTypes.DUST_PILLAR,
            ParticleTypes.TOTEM_OF_UNDYING,
            ParticleTypes.REVERSE_PORTAL,
            ParticleTypes.SMOKE,
            ParticleTypes.LARGE_SMOKE,
            ParticleTypes.CLOUD,
            ParticleTypes.POOF,
            ParticleTypes.FLASH,
            ParticleTypes.SWEEP_ATTACK,
            ParticleTypes.DAMAGE_INDICATOR);

    public Particulas() {
        super("Particulas", Category.MISC);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public boolean defaultEnabled() { return true; }

    /** Usado pelos mixins. */
    public static boolean isActive() {
        if (MeuClient.modules == null) return true; // ainda carregando: ja corta
        Module m = MeuClient.modules.get("Particulas");
        return m == null || m.isEnabled();
    }

    public static boolean shouldBlock(ParticleType<?> type) {
        return BLOCKED.contains(type) && isActive(); // o teste barato primeiro: a maioria das particulas nem chega no get()
    }
}
