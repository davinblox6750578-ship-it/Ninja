package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * ESP de mobs: copia do BoxESP, so que nos mobs (hostis e passivos, o mesmo conceito de "mob" do
 * KillMob). Caixa 3D branca com o NOME do mob e a distancia em cima. Como e desenhado na tela
 * (projecao do mundo para o HUD), aparece atraves das paredes.
 */
public class ESPMob extends Module {
    private static final int BRIGHT = 0xFFFFFFFF; // linha principal (branco)
    private static final int GLOW = 0x33FFFFFF;   // brilho em volta (branco)
    private static final double NEAR = 0.05;
    private static final double MAX_DIST = 160.0; // muito longe: nao gasta desenho
    private static boolean registered;

    public ESPMob() {
        super("ESPMob", Category.WORLD); // mesma categoria do KillMob: aparece logo abaixo dele no menu
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
        if (!registered) {
            registered = true;
            HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                    Identifier.of("ninjaclient", "espmob"), (ctx, tickCounter) -> render(ctx));
        }
    }

    private void render(DrawContext ctx) {
        if (!isEnabled() || mc.world == null || mc.player == null) return;

        float delta = mc.getRenderTickCounter().getTickProgress(false);
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d camPos = cam.getPos();

        double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
        Vec3d fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3d right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        Vec3d up = right.crossProduct(fwd);

        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double tanHalf = com.meuclient.Projection.tanHalfFov(mc);
        double aspect = (double) sw / sh;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof MobEntity mob) || !mob.isAlive()) continue;
            if (mc.player.distanceTo(mob) > MAX_DIST) continue;

            Vec3d pos = mob.getLerpedPos(delta);
            double hw = mob.getWidth() / 2.0 + 0.05, h = mob.getHeight() + 0.1;

            // 8 cantos no espaco da camera: {direita, cima, frente}
            double[][] cs = new double[8][];
            for (int i = 0; i < 8; i++) {
                Vec3d corner = new Vec3d(
                        pos.x + ((i & 1) == 0 ? -hw : hw),
                        pos.y - 0.05 + ((i & 2) == 0 ? 0 : h),
                        pos.z + ((i & 4) == 0 ? -hw : hw));
                Vec3d d = corner.subtract(camPos);
                cs[i] = new double[]{d.dotProduct(right), d.dotProduct(up), d.dotProduct(fwd)};
            }

            double topY = Double.MAX_VALUE, centerX = 0;
            int pts = 0;

            // 12 arestas: cantos que diferem em um unico bit
            for (int i = 0; i < 8; i++) {
                for (int bit = 1; bit <= 4; bit <<= 1) {
                    if ((i & bit) != 0) continue;
                    double[] a = cs[i], b = cs[i | bit];
                    if (a[2] < NEAR && b[2] < NEAR) continue; // inteira atras da camera
                    if (a[2] < NEAR) a = clip(a, b);
                    else if (b[2] < NEAR) b = clip(b, a);

                    double ax = sw / 2.0 + (a[0] / a[2]) / (tanHalf * aspect) * (sw / 2.0);
                    double ay = sh / 2.0 - (a[1] / a[2]) / tanHalf * (sh / 2.0);
                    double bx = sw / 2.0 + (b[0] / b[2]) / (tanHalf * aspect) * (sw / 2.0);
                    double by = sh / 2.0 - (b[1] / b[2]) / tanHalf * (sh / 2.0);

                    com.meuclient.Draw.line(ctx, ax, ay, bx, by, sw, sh, BRIGHT, GLOW);
                    topY = Math.min(topY, Math.min(ay, by));
                    centerX += ax + bx;
                    pts += 2;
                }
            }

            if (pts > 0) {
                String label = mob.getName().getString() + " " + Math.round(mc.player.distanceTo(mob)) + "m";
                int tw = mc.textRenderer.getWidth(label);
                int lx = (int) (centerX / pts) - tw / 2;
                int ly = (int) topY - 11;
                if (ly > -10 && ly < sh && lx + tw > 0 && lx < sw) {
                    ctx.drawText(mc.textRenderer, label, lx, ly, 0xFFFFFFFF, true);
                }
            }
        }
    }

    /** Corta a aresta no plano proximo da camera (z = NEAR). `behind` esta atras, `front` na frente. */
    private static double[] clip(double[] behind, double[] front) {
        double t = (NEAR - behind[2]) / (front[2] - behind[2]);
        return new double[]{
                behind[0] + (front[0] - behind[0]) * t,
                behind[1] + (front[1] - behind[1]) * t,
                NEAR};
    }
}
