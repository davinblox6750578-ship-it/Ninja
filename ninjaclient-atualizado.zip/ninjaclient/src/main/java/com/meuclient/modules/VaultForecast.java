package com.meuclient.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Tenta prever o proximo item exibido por UMA caixa (vault), a partir do que ja foi observado.
 * Sem Minecraft: so tempo (nanos) e itens, para poder ser verificado fora do jogo.
 *
 * Vanilla: o item exibido e re-sorteado a cada ~1 s pelo servidor (aleatorio, nao previsivel).
 * Esta classe so acha previsao quando o servidor repete uma SEQUENCIA (ciclo) de itens, com
 * intervalo regular entre as trocas. Sem isso, period() = 0 e nada e previsto.
 *
 * O servidor so manda atualizacao quando o item muda; trocas "para o mesmo item" nao geram
 * evento, entao o intervalo entre eventos pode ser multiplo do intervalo base e a sequencia e
 * reconstruida repetindo o item nos intervalos sem evento.
 */
final class VaultForecast<T> {
    static final long NONE = Long.MIN_VALUE;
    static final int MAX_PERIOD = 24;          // maior ciclo procurado (em trocas)
    static final int MIN_CONFIRM = 12;         // trocas seguidas que precisam repetir o padrao
    static final int MAX_HISTORY = 200;
    static final int MIN_DELTAS = 6;           // intervalos medidos antes de estimar a cadencia
    static final int RECENT_DELTAS = 12;
    static final double TOLERANCE = 0.12;      // desvio aceito do intervalo, em fracao do intervalo base
    static final double MIN_REGULAR = 0.85;    // fracao dos intervalos recentes que precisa ser regular
    static final long MIN_BASE_NANOS = 50_000_000L;
    static final long MAX_HORIZON_NANOS = 6_000_000_000L;

    private final ArrayList<T> slots = new ArrayList<>(); // item de cada "troca", em ordem
    private final ArrayList<Long> deltas = new ArrayList<>();
    private T lastItem;
    private long lastNanos;
    private boolean hasLast;
    private long base;    // intervalo base estimado (0 = ainda desconhecido)
    private int period;   // tamanho do ciclo achado (0 = nenhum)
    private final int maxHistory;

    VaultForecast() { this(MAX_HISTORY); }

    VaultForecast(int maxHistory) { this.maxHistory = maxHistory; }

    /** Registra o item exibido agora. So conta se mudou. Retorna true se foi um evento novo. */
    boolean observe(long nowNanos, T item) {
        if (hasLast && Objects.equals(item, lastItem)) return false;
        if (hasLast) {
            long d = nowNanos - lastNanos;
            long b0 = estimateBase();
            if (d <= 0 || (b0 > 0 && d > b0 * MAX_PERIOD)) {
                slots.clear();   // caixa ficou parada ou o relogio voltou: recomeca
                deltas.clear();
            } else {
                deltas.add(d);
                while (deltas.size() > maxHistory) deltas.remove(0);
                long b = estimateBase();
                int k = b > 0 ? (int) Math.max(1, Math.round((double) d / b)) : 1;
                for (int i = 1; i < k; i++) slots.add(lastItem); // trocas sem evento: mesmo item
            }
        }
        slots.add(item);
        while (slots.size() > maxHistory) slots.remove(0);
        lastItem = item;
        lastNanos = nowNanos;
        hasLast = true;
        base = estimateBase();
        period = computePeriod();
        return true;
    }

    int period() { return period; }

    /** Itens por troca, em ordem (repeticoes sem evento incluidas). */
    List<T> slots() { return new ArrayList<>(slots); }

    /** O ciclo achado, comecando pelo proximo item a aparecer; vazio se nao ha ciclo. */
    List<T> cycle() {
        if (period == 0) return new ArrayList<>();
        return new ArrayList<>(slots.subList(slots.size() - period, slots.size()));
    }

    long baseNanos() { return base; }

    /**
     * Instante (nanos, mesmo relogio de observe) em que o item `wanted` deve aparecer na proxima
     * vez, ou NONE se nao ha ciclo confirmado, a informacao esta velha ou o item nao esta no ciclo.
     * So olha trocas ainda no futuro e ate um ciclo inteiro a frente.
     */
    long predictArrival(T wanted, long nowNanos) {
        if (!hasLast || period == 0 || base <= 0) return NONE;
        if (nowNanos - lastNanos > 3 * base) return NONE; // sem eventos ha tempo: ciclo velho
        int n0 = slots.size();
        for (int n = 1; n <= period; n++) {
            long t = lastNanos + n * base;
            if (t - nowNanos > MAX_HORIZON_NANOS) break;
            if (t <= nowNanos) continue;
            T item = slots.get(n0 - period + ((n - 1) % period));
            if (Objects.equals(item, wanted)) return t;
        }
        return NONE;
    }

    /** Intervalo base: percentil 25 dos intervalos refinado pela mediana dos proximos a ele. */
    private long estimateBase() {
        if (deltas.size() < MIN_DELTAS) return 0;
        List<Long> sorted = new ArrayList<>(deltas);
        Collections.sort(sorted);
        long q = sorted.get(sorted.size() / 4);
        if (q < MIN_BASE_NANOS) return 0;
        List<Long> near = new ArrayList<>();
        for (long d : sorted) if (d >= q * 0.85 && d <= q * 1.15) near.add(d);
        return near.get(near.size() / 2);
    }

    /** Os intervalos recentes sao multiplos do base (dentro da tolerancia)? */
    boolean regular() {
        if (base <= 0) return false;
        int from = Math.max(0, deltas.size() - RECENT_DELTAS);
        int good = 0, total = 0;
        for (int i = from; i < deltas.size(); i++) {
            double r = (double) deltas.get(i) / base;
            long k = Math.round(r);
            total++;
            if (k >= 1 && Math.abs(r - k) <= TOLERANCE) good++;
        }
        return total >= MIN_DELTAS && good >= MIN_REGULAR * total;
    }

    /** Menor periodo p tal que as ultimas max(MIN_CONFIRM, 2p) trocas repetem a de p trocas antes. */
    private int computePeriod() {
        if (!regular()) return 0;
        int n = slots.size();
        for (int p = 1; p <= MAX_PERIOD; p++) {
            int need = Math.max(MIN_CONFIRM, 2 * p);
            if (n < need + p) break; // precisa de mais historico (e cresce com p)
            boolean ok = true;
            for (int j = n - need; j < n; j++) {
                if (!Objects.equals(slots.get(j), slots.get(j - p))) { ok = false; break; }
            }
            if (ok) return p;
        }
        return 0;
    }
}
