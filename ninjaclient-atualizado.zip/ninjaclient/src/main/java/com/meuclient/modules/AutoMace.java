package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

/**
 * Caindo de uma altura (queda > 1,5 blocos, o minimo do smash no vanilla):
 * mira no jogador ao alcance e ataca com a clava.
 *
 *  - a clava e equipada UMA vez por queda (a queda recomeca ao pousar ou enquanto voce sobe), so depois de cair mais de EQUIP_FALL blocos (um
 *    pulo comum cai ~1,25 e NAO equipa) e com um jogador a EQUIP_RANGE blocos E abaixo de voce
 *    (inimigo no mesmo nivel ou atras de voce nao equipa); se voce trocar de slot de proposito, o modulo nao briga com voce;
 *  - o smash ignora a barra de cooldown, entao ataca assim que o alvo entra no alcance;
 *  - o alcance e medido ate a CAIXA do alvo (como o servidor faz);
 *  - nao ataca se o alvo estiver bloqueando com escudo;
 *  - golpeia de novo na MESMA queda: enquanto estiver no ar, com o alvo ao alcance e a queda
 *    (fallDistance) acima de MIN_FALL, ataca a cada MIN_GAP_TICKS ticks.
 */
public class AutoMace extends Module {
    private static final double REACH = 3.0;         // olhos -> caixa do alvo
    private static final double EQUIP_RANGE = 12.0;  // pega a clava quando alguem chega perto
    private static final double EQUIP_FALL = 1.6;    // so equipa depois de cair mais que isso (um pulo comum cai ~1,25)
    private static final double EQUIP_BELOW = 1.0;   // o inimigo precisa estar pelo menos isso abaixo de voce
    private static final double MIN_FALL = 1.5;      // queda minima para o smash
    private static final int MIN_GAP_TICKS = 10;     // intervalo minimo entre golpes

    private boolean equipTried;
    private boolean rose;      // subiu neste voo (wind charge/burst): queda medida desde o apice
    private double apexY = Double.NaN;
    private int gap;

    public AutoMace() {
        super("AutoMace", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onDisable() {
        newFall();
        rose = false;
        apexY = Double.NaN;
        gap = 0;
    }

    @Override
    public void onTick() {
        if (gap > 0) gap--;
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || !mc.player.isAlive()) return;

        double y = mc.player.getY();

        // pousou: queda nova
        if (mc.player.isOnGround()) {
            newFall();
            rose = false;
            apexY = y;
            return;
        }

        // subindo (wind charge, wind burst): a queda recomeca no apice. Sem isso, o equip
        // "uma vez por queda" ficava travado se voce nao pousasse entre uma queda e outra
        if (mc.player.getVelocity().y > 0) {
            newFall();
            rose = true;
            apexY = y;
            return;
        }

        // queda propria (apice - altura atual): depois de subir, o fallDistance do cliente pode
        // estar velho (alto demais, golpe sem smash) ou zerado (nao ataca); entao nao confio nele.
        // Sem ter subido (pulo, borda), vale o maior dos dois.
        if (Double.isNaN(apexY) || y > apexY) apexY = y;
        double fall = rose ? apexY - y : Math.max(mc.player.fallDistance, apexY - y);
        if (!Double.isFinite(fall)) return;

        // clava fora da mao: equipa uma unica vez por queda (trocar zera o cooldown, mas o
        // bonus do smash nao depende da barra)
        if (!mc.player.getMainHandStack().isOf(Items.MACE)) {
            if (!equipTried && fall > EQUIP_FALL && enemyBelow()) {
                equipTried = true;
                selectMace();
            }
            return;
        }

        if (gap > 0 || fall <= MIN_FALL) return;

        PlayerEntity target = Combat.nearestPlayerInReach(mc, REACH);
        if (target == null) return;

        // escudo levantado: o smash seria bloqueado, entao espera ele abaixar
        if (target.isBlocking()) return;

        Combat.aimAt(mc, target, 180f);
        Combat.attack(mc, target);
        gap = MIN_GAP_TICKS;
    }

    /** Tem jogador a EQUIP_RANGE blocos e pelo menos EQUIP_BELOW abaixo de voce (alvo de uma queda)? */
    private boolean enemyBelow() {
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator()) continue;
            if (mc.player.distanceTo(p) > EQUIP_RANGE) continue;
            if (p.getY() <= mc.player.getY() - EQUIP_BELOW) return true;
        }
        return false;
    }

    private void newFall() {
        equipTried = false;
    }

    private void selectMace() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.MACE)) {
                mc.player.getInventory().setSelectedSlot(i);
                return;
            }
        }
    }
}
