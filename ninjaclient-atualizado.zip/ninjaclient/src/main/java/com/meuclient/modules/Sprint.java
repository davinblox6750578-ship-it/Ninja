package com.meuclient.modules;

import com.meuclient.Module;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", com.meuclient.Category.MOVEMENT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onTick() {
        if (mc.player.forwardSpeed > 0 && !mc.player.horizontalCollision) {
            mc.player.setSprinting(true);
        }
    }
}
