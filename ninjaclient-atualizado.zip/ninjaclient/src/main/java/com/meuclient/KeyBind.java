package com.meuclient;

/**
 * Regra de captura de tecla no mapeamento: Esc cancela (fica a tecla de antes), Backspace e
 * Delete REMOVEM a tecla (sem atalho), qualquer outra vira o atalho. Sem Minecraft/GLFW para
 * poder ser verificada fora do jogo; os codigos sao os do GLFW.
 */
public final class KeyBind {
    public static final int NONE = -1;
    private static final int ESCAPE = 256, BACKSPACE = 259, DELETE = 261; // GLFW_KEY_ESCAPE/BACKSPACE/DELETE

    private KeyBind() {}

    /** Nova tecla do modulo depois de `pressed` ser apertada durante o mapeamento. */
    public static int result(int pressed, int current) {
        if (pressed == ESCAPE) return current;
        if (pressed == BACKSPACE || pressed == DELETE) return NONE;
        return pressed;
    }
}
