package com.meuclient;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public abstract class Module {
    public final String name;
    public final Category category;
    private boolean enabled;
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    // tecla de atalho que liga/desliga o modulo (opcional)
    private boolean hasToggleKey;
    private int toggleKey;
    private boolean toggleKeyHeld;
    private boolean bindingKey;

    public Module(String name, Category category) {
        this.category = category;
        this.name = name;
    }

    /** Ativa o atalho: apertar a tecla liga/desliga o modulo. Use -1 para comecar sem tecla; mapeie no menu. */
    protected void enableToggleKey(int defaultKey) {
        hasToggleKey = true;
        toggleKey = defaultKey;
    }

    public static String keyName(int key) {
        if (key < 0) return "--"; // sem tecla
        String name = GLFW.glfwGetKeyName(key, 0);
        String label = name != null ? name.toUpperCase() : "#" + key;
        return label.length() > 4 ? label.substring(0, 4) : label;
    }

    public boolean isEnabled() { return enabled; }

    /** true = o modulo vem ligado na primeira vez (antes de existir config salva). */
    public boolean defaultEnabled() { return false; }

    // ---- ganchos usados pela Config (salvar/carregar) ----
    public boolean hasKey() { return hasToggleKey; }
    public int getKey() { return toggleKey; }
    public void setKey(int k) { if (hasToggleKey) toggleKey = k; }

    /** Opcao extra do modulo para salvar (ex.: parte do corpo); null = nenhuma. */
    public String getExtra() { return null; }
    public void setExtra(String value) {}

    /** Liga/desliga sem mensagem na tela (usado ao carregar a config). */
    public void loadEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (on) onEnable(); else onDisable();
    }

    /** true = modulo de configuracao: o clique abre um painel em vez de ligar/desligar. */
    public boolean isSettings() { return false; }

    public void toggle() {
        enabled = !enabled;
        Config.markDirty();
        if (enabled) onEnable(); else onDisable();
        if (mc.player != null) {
            mc.player.sendMessage(net.minecraft.text.Text.literal(
                "§7[NinjaClient] §f" + name + (enabled ? " §aON" : " §cOFF")), true);
        }
    }

    /** Texto extra mostrado ao lado do nome no menu (ex.: opcao atual). */
    public String suffix() { return ""; }

    /** Texto do botao de tecla mostrado no menu; null = modulo sem tecla. */
    public String bindLabel() {
        if (!hasToggleKey) return null;
        return bindingKey ? "..." : keyName(toggleKey);
    }

    /** Chamado quando o jogador clica no botao de tecla no menu. */
    public void onBindClick() {
        if (hasToggleKey) startBinding();
    }

    /** Chamado quando o jogador clica com o botao direito no modulo no menu. */
    public void onRightClick() {
        if (hasToggleKey) startBinding();
    }

    private void startBinding() {
        bindingKey = true;
        if (mc.player != null) {
            mc.player.sendMessage(net.minecraft.text.Text.literal(
                "\u00a77[NinjaClient] \u00a7f" + name + ": aperte a tecla (Backspace/Delete = remover, Esc = cancelar)"), true);
        }
    }

    /**
     * Chamado todo tick, mesmo com o modulo desligado.
     * Aqui: captura a nova tecla e liga/desliga ao apertar o atalho.
     */
    public void onBackgroundTick() {
        if (!hasToggleKey) return;
        long window = mc.getWindow().getHandle();

        if (bindingKey) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                if (k == GLFW.GLFW_KEY_RIGHT_ALT) continue; // tecla do menu
                if (GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS) {
                    int next = KeyBind.result(k, toggleKey); // Esc cancela, Backspace/Delete removem
                    if (next != toggleKey) { toggleKey = next; Config.markDirty(); }
                    bindingKey = false;
                    toggleKeyHeld = true; // nao conta como aperto
                    return;
                }
            }
            return;
        }

        boolean down = toggleKey >= 0 && mc.currentScreen == null
                && GLFW.glfwGetKey(window, toggleKey) == GLFW.GLFW_PRESS;
        if (down && !toggleKeyHeld) toggle();
        toggleKeyHeld = down;
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
}
