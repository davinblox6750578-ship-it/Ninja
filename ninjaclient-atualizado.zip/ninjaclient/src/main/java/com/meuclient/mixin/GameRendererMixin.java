package com.meuclient.mixin;

import com.meuclient.Projection;
import com.meuclient.modules.Particulas;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Tira a animacao do totem que aparece na tela (o item girando). */
@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "showFloatingItem", at = @At("HEAD"), cancellable = true)
    private void ninjaclient$skipTotemAnimation(ItemStack stack, CallbackInfo ci) {
        if (Particulas.isActive() && stack.isOf(Items.TOTEM_OF_UNDYING)) {
            ci.cancel();
        }
    }

    /** Guarda o FOV real do mundo (usado pelos ESPs). require = 0: se o metodo mudar, so cai no FOV das opcoes. */
    @Inject(method = "getFov(Lnet/minecraft/client/render/Camera;FZ)F", at = @At("RETURN"), require = 0)
    private void ninjaclient$captureFov(Camera camera, float tickProgress, boolean changingFov,
                                        CallbackInfoReturnable<Float> cir) {
        if (changingFov) Projection.worldFov = cir.getReturnValue();
    }
}
