package com.meuclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Acompanha a velocidade dos jogadores para os ESPs (caixa, linha e vida).
 * Quando o inimigo corre, a posicao que o cliente conhece fica um pouco atras
 * do boneco na tela; aqui estimamos a velocidade (blocos por tick) e somamos
 * LEAD_TICKS de antecipacao, para a caixa/texto acompanharem o boneco.
 * Se ainda ficar para tras, aumente LEAD_TICKS; se passar na frente, diminua.
 */
public final class PlayerTracker {
    private PlayerTracker() {}

    // 0 = sem antecipacao: o boneco e desenhado em getLerpedPos(delta), a MESMA posicao da caixa.
    // Antecipar 1 tick empurrava a caixa para a frente do boneco quando ele andava.
    public static final double LEAD_TICKS = 0.0;

    private static final Map<Integer, Vec3d> last = new HashMap<>();
    private static final Map<Integer, Vec3d> velocity = new HashMap<>();

    /** Chamado uma vez por tick do cliente. */
    public static void update(MinecraftClient mc) {
        if (LEAD_TICKS == 0.0) return; // sem antecipacao a velocidade nao e usada: nao gasta nada
        if (mc.world == null || !anyEspOn()) {
            if (!last.isEmpty()) { last.clear(); velocity.clear(); }
            return; // nenhum ESP ligado: nao gasta processamento
        }
        Set<Integer> seen = new HashSet<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p)) continue;
            int id = p.getId();
            seen.add(id);
            Vec3d pos = new Vec3d(p.getX(), p.getY(), p.getZ());
            Vec3d prev = last.put(id, pos);
            if (prev == null) continue;
            Vec3d v = pos.subtract(prev);
            Vec3d old = velocity.get(id);
            // suaviza um pouco para nao tremer
            velocity.put(id, old == null ? v : old.multiply(0.4).add(v.multiply(0.6)));
        }
        last.keySet().retainAll(seen);
        velocity.keySet().retainAll(seen);
    }

    private static boolean anyEspOn() {
        if (MeuClient.modules == null) return false;
        for (String name : new String[]{"BoxESP", "ESPVida", "ESPLine"}) {
            Module m = MeuClient.modules.get(name);
            if (m != null && m.isEnabled()) return true;
        }
        return false;
    }

    /** Posicao para desenhar: suavizada entre ticks + antecipacao pela velocidade. */
    public static Vec3d renderPos(PlayerEntity p, float delta) {
        Vec3d base = p.getLerpedPos(delta);
        if (LEAD_TICKS == 0.0) return base; // mesma posicao de antes (base + 0 * velocidade)
        Vec3d v = velocity.get(p.getId());
        return v == null ? base : base.add(v.multiply(LEAD_TICKS));
    }
}
