package com.meuclient;

import com.meuclient.modules.*;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public final List<Module> modules = new ArrayList<>();
    private boolean menuKeyHeld;

    public ModuleManager() {
        modules.add(new KillAura());
        modules.add(new AimAssist());
        modules.add(new TriggerBot());
        modules.add(new AutoClicker());
        modules.add(new AutoMace());
        modules.add(new AutoElytra());
        modules.add(new AutoCrystal());
        modules.add(new AutoAnchor());
        modules.add(new AutoLanca());
        modules.add(new AutoTotem());
        modules.add(new Scaffold());
        modules.add(new KillMob());
        modules.add(new ESPMob());
        modules.add(new AutoVaultSuper());
        modules.add(new PotVault());
        modules.add(new NoFall());
        modules.add(new Fly());
        modules.add(new Sprint());
        modules.add(new Fullbright());
        modules.add(new ESP());
        modules.add(new BoxESP());
        modules.add(new ESPVida());
        modules.add(new ESPLine());
        modules.add(new Cores());
        modules.add(new Particulas());
        modules.add(new Capa());
        reindex();
    }

    // busca por nome em O(log n) e sem criar String: os mixins chamam get() varias vezes por frame
    // (capa a cada getSkin, particulas a cada addParticle, NoFall a cada pacote de movimento)
    private final java.util.Map<String, Module> byName = new java.util.TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    private int indexedCount = -1;

    private void reindex() {
        byName.clear();
        for (Module m : modules) byName.putIfAbsent(m.name, m); // mesmo criterio de antes: o primeiro com o nome vence
        indexedCount = modules.size();
    }

    public Module get(String name) {
        if (name == null) return null;
        if (indexedCount != modules.size()) reindex(); // a lista mudou depois de montada
        return byName.get(name);
    }

    public void tick(MinecraftClient mc) {
        PlayerTracker.update(mc);
        if (mc.player == null || mc.world == null) return;

        // AltGr = Alt direito (GLFW_KEY_RIGHT_ALT)
        boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_ALT) == GLFW.GLFW_PRESS;
        if (down && !menuKeyHeld && mc.currentScreen == null) {
            mc.setScreen(new NinjaMenuScreen());
        }
        menuKeyHeld = down;

        for (Module m : modules) {
            m.onBackgroundTick();
            if (m.isEnabled()) m.onTick();
        }
    }
}
