package com.meuclient;

import net.minecraft.client.gui.DrawContext;

/**
 * Desenho de linhas leve para os ESPs. Em vez de um retangulo por pixel,
 * agrupa pixels seguidos na mesma linha/coluna em UM retangulo (run-length),
 * o que reduz muito o numero de chamadas de desenho por frame e ajuda o FPS.
 */
public final class Draw {
    private Draw() {}

    private static final int MAX_STEPS = 1500;

    /** Linha 2D recortada para a tela (Liang-Barsky). glow = 0 desliga o brilho. */
    public static void line(DrawContext ctx, double x0, double y0, double x1, double y1,
                            int sw, int sh, int core, int glow) {
        double dx = x1 - x0, dy = y1 - y0;
        double t0 = 0, t1 = 1;
        double[] p = {-dx, dx, -dy, dy};
        double[] q = {x0, sw - x0, y0, sh - y0};
        for (int i = 0; i < 4; i++) {
            if (p[i] == 0) {
                if (q[i] < 0) return;
            } else {
                double r = q[i] / p[i];
                if (p[i] < 0) { if (r > t1) return; if (r > t0) t0 = r; }
                else          { if (r < t0) return; if (r < t1) t1 = r; }
            }
        }
        double sx = x0 + dx * t0, sy = y0 + dy * t0, ex = x0 + dx * t1, ey = y0 + dy * t1;
        double ddx = ex - sx, ddy = ey - sy;
        boolean horizontal = Math.abs(ddx) >= Math.abs(ddy);
        int steps = (int) Math.min(MAX_STEPS, Math.max(Math.abs(ddx), Math.abs(ddy)));
        if (steps <= 0) return;

        int runStart = 0, runEnd = 0, runMinor = 0;
        for (int i = 0; i <= steps; i++) {
            int x = (int) (sx + ddx * i / steps), y = (int) (sy + ddy * i / steps);
            int major = horizontal ? x : y, minor = horizontal ? y : x;
            if (i == 0) {
                runStart = runEnd = major;
                runMinor = minor;
            } else if (minor == runMinor) {
                runEnd = major;
            } else {
                flush(ctx, horizontal, runStart, runEnd, runMinor, core, glow);
                runStart = runEnd = major;
                runMinor = minor;
            }
        }
        flush(ctx, horizontal, runStart, runEnd, runMinor, core, glow);
    }

    private static void flush(DrawContext ctx, boolean horizontal, int a, int b, int minor, int core, int glow) {
        int lo = Math.min(a, b), hi = Math.max(a, b) + 1;
        if (horizontal) {
            if (glow != 0) ctx.fill(lo - 1, minor - 1, hi + 1, minor + 2, glow);
            ctx.fill(lo, minor, hi, minor + 1, core);
        } else {
            if (glow != 0) ctx.fill(minor - 1, lo - 1, minor + 2, hi + 1, glow);
            ctx.fill(minor, lo, minor + 1, hi, core);
        }
    }
}
